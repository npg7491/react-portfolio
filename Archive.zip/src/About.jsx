import React from 'react';

function About() {
    // Since the 'aos' library is not available in this environment,
    // the useEffect hook for initialization has been removed.

    return (
        <>
          {/* Styles that were previously in About.css are now included here */}
          <style>{`
            .content-section {
              padding: 4rem 2rem;
              max-width: 1200px;
              margin: 0 auto;
            }
            .about-container {
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2rem;
            }
            @media (min-width: 768px) {
              .about-container {
                flex-direction: row;
                align-items: flex-start;
              }
            }
            .profile-pic {
              width: 200px;
              height: 200px;
              border-radius: 50%;
              object-fit: cover;
              border: 5px solid #ddd;
            }
            .about-text {
              flex: 1;
              text-align: center;
            }
             @media (min-width: 768px) {
              .about-text {
                text-align: left;
              }
            }
            .about-text p {
              font-size: 1.1rem;
              line-height: 1.6;
              margin-bottom: 2rem;
            }
            .resume-button-container {
              margin-bottom: 2rem;
            }
            .submit-button {
              background-color: #007bff;
              color: white;
              padding: 1rem 2rem;
              border-radius: 5px;
              text-decoration: none;
              font-weight: bold;
              transition: background-color 0.3s;
            }
            .submit-button:hover {
              background-color: #0056b3;
            }
            .devicon-html5-plain, .devicon-css3-plain, .devicon-javascript-plain,
            .devicon-react-original, .devicon-nodejs-plain, .devicon-express-original,
            .devicon-mongodb-plain, .devicon-git-plain, .devicon-github-original {
                font-size: 3rem; /* Increased size for better visibility */
            }
          `}</style>
          
          {/* Link to the Devicon stylesheet in the head */}
          <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/devicons/devicon@v2.15.1/devicon.min.css" />

          <section id="about" className="content-section">
            <h2>About Me</h2>
            <div className="about-container">
              {/* Using a placeholder image as the local file is not accessible */}
              <img src="https://placehold.co/200x200/EFEFEF/3A3A3A?text=NP" alt="Ninoska Peralta" className="profile-pic" />
              <div className="about-text">
                <p>I'm a Full-Stack Developer and aspiring Project Manager focused on crafting scalable, user-friendly web applications. Currently completing full-stack and PM certifications through Microsoft, IBM, and Google, I'm ready to contribute to cross-functional teams and grow through hands-on collaboration.</p>
                
                <div className="resume-button-container">
                  {/* The resume file path is kept as is, assuming it will be in the public folder */}
                  <a href="/ninoskaperalta_fullstack_pm_resume.docx.pdf" download className="submit-button">Download My Resume</a>
                </div>

                <div style={{ marginTop: '2rem', textAlign: 'center' }}>
                  <h3>Tech Stack</h3>
                  <div style={{ fontSize: '2rem', display: 'flex', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap' }}>
                    <i className="devicon-html5-plain colored" title="HTML5"></i>
                    <i className="devicon-css3-plain colored" title="CSS3"></i>
                    <i className="devicon-javascript-plain colored" title="JavaScript"></i>
                    <i className="devicon-react-original colored" title="React"></i>
                    <i className="devicon-nodejs-plain colored" title="Node.js"></i>
                    <i className="devicon-express-original colored" title="Express"></i>
                    <i className="devicon-mongodb-plain colored" title="MongoDB"></i>
                    <i className="devicon-git-plain colored" title="Git"></i>
                    <i className="devicon-github-original colored" title="GitHub"></i>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </>
    );
}

export default About;

