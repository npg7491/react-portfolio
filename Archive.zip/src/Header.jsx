import React from 'react';
// Make sure to create and import a corresponding CSS file for styling
import './Header.css';

// The component receives 'isMenuOpen' and 'toggleMenu' as props from App.jsx
function Header({ isMenuOpen, toggleMenu }) {
  return (
    <header>
      {/* Note: The 'class' attribute from HTML is changed to 'className' in JSX */}
      <nav className="navbar">
        <a href="#" className="nav-branding">Ninoska Peralta</a>

        {/* This is the key part:
          We use a ternary operator to conditionally add the 'active' class 
          to the menu based on the 'isMenuOpen' state.
        */}
        <ul className={isMenuOpen ? "nav-menu active" : "nav-menu"}>
          <li className="nav-item"><a href="#about" className="nav-link">About</a></li>
          <li className="nav-item"><a href="#projects" className="nav-link">Projects</a></li>
          <li className="nav-item"><a href="#contact" className="nav-link">Contact</a></li>
        </ul>

        <div className="nav-controls">
          <button id="theme-toggle" title="Toggle theme">🌙</button>

          {/* This div is now a button. When clicked, it calls the toggleMenu 
            function that was passed down from the App component.
            It also gets an 'active' class when the menu is open.
          */}
          <div 
            className={isMenuOpen ? "hamburger active" : "hamburger"} 
            onClick={toggleMenu}
          >
            <span className="bar"></span>
            <span className="bar"></span>
            <span className="bar"></span>
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Header;