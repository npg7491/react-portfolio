import React, { useState, useEffect } from 'react';

// A custom hook for the typewriter effect
const useTypewriter = (words, { loop = true, typeSpeed = 120, deleteSpeed = 50, delaySpeed = 1500 } = {}) => {
    const [text, setText] = useState('');
    const [isDeleting, setIsDeleting] = useState(false);
    const [loopNum, setLoopNum] = useState(0);
    const [typingSpeed, setTypingSpeed] = useState(typeSpeed);

    useEffect(() => {
        let handle;
        const currentWord = words[loopNum % words.length];

        // This function handles the typing logic
        const handleType = () => {
            if (isDeleting) {
                // Deleting logic
                setText(currentWord.substring(0, text.length - 1));
                setTypingSpeed(deleteSpeed);
            } else {
                // Typing logic
                setText(currentWord.substring(0, text.length + 1));
                setTypingSpeed(typeSpeed);
            }

            // When a word is fully typed
            if (!isDeleting && text === currentWord) {
                setTimeout(() => setIsDeleting(true), delaySpeed);
            } 
            // When a word is fully deleted
            else if (isDeleting && text === '') {
                // If we are on the last word and looping is disabled, stop the effect.
                if (!loop && loopNum === words.length - 1) {
                    return; 
                }
                
                setIsDeleting(false);
                // Move to the next word in the array
                setLoopNum(loopNum + 1);
            }
        };

        // Set a timeout to call the typing handler
        handle = setTimeout(handleType, typingSpeed);

        // Cleanup function to clear timeout on component unmount
        return () => clearTimeout(handle);
    }, [text, isDeleting, loopNum, words, loop, typeSpeed, deleteSpeed, delaySpeed]); // Added 'loop' to dependency array

    return text;
};


function Hero() {
    // Array of phrases to be typed out
    const phrases = [
        "Hello, I'm Ninoska Peralta.",
        "I'm a Full-Stack Developer.",
        "I'm an aspiring Project Manager."
    ];
    
    // You can now pass options, e.g., useTypewriter(phrases, { loop: false });
    const animatedText = useTypewriter(phrases);

    return (
        <>
          {/* Styles for the Hero section */}
          <style>{`
            .hero-section {
              display: flex;
              flex-direction: column;
              justify-content: center;
              align-items: center;
              height: 100vh; /* Full viewport height */
              text-align: center;
              background-color: #f8f9fa; /* A light grey background */
              padding: 0 2rem;
            }
            .hero-section h1 {
              font-size: 2.5rem;
              margin-bottom: 1rem;
              font-weight: 700;
            }
            @media(min-width: 768px) {
                .hero-section h1 {
                    font-size: 4rem;
                }
            }
            .hero-section p {
              font-size: 1.25rem;
              max-width: 600px;
              color: #6c757d; /* A muted grey color for the subtitle */
            }
            .typewriter-cursor {
                border-left: 2px solid #333;
                animation: blink 0.7s steps(1) infinite;
            }
            @keyframes blink {
                50% {
                    border-color: transparent;
                }
            }
          `}</style>

          <section id="hero" className="hero-section">
            <h1>
              {/* The animated text will appear here */}
              <span className="typewriter-text">{animatedText}</span>
              {/* A blinking cursor effect */}
              <span className="typewriter-cursor"></span>
            </h1>
            <p>A student developer dedicated to building complete web applications from the ground up.</p>
          </section>
        </>
    );
}

export default Hero;

